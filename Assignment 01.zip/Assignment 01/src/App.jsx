import './App.css'

function App() {

  const products = [
    {
      name: "Anniversary gifts",
      img: "../public/images/card1.avif"
    },
    {
      name: "Gifts for him",
      img: "../public/images/card2.avif"
    },
    {
      name: "Gifts for her",
      img: "../public/images/card3.avif"
    },
    {
      name: "Personalised gift idea",
      img: "../public/images/card4.avif"
    },
    {
      name: "Weding gifts",
      img: "../public/images/card5.avif"
    },
  ]

  return (
    <div id='parent'>
      <h2 className='heading'>Shop our popular gift categories</h2>
      <div className='parent'>
          {products.map((item, index) => (
            <div key={index} className='card'>
              <img src={item.img} alt={item.name} />
              <h2>{item.name}</h2>
            </div>
          ))}
      </div>
    </div>
  )
}

export default App
